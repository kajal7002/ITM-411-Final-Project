import java.math.*;
import java.security.*;

public class Encrypt {
	public static String MD5Encrypt(String password){
		try {
			MessageDigest msgDg = MessageDigest.getInstance("MD5");
			byte[] pwrdDigest = msgDg.digest(password.getBytes());
			BigInteger num =  new BigInteger(1, pwrdDigest);
			String hashedPwrd = num.toString(16);
			while(hashedPwrd.length() < 32) { // Specify the length of string
				hashedPwrd = "0" + hashedPwrd;
			}
			return hashedPwrd;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
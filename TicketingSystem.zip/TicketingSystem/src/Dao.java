//

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Dao {

	// Code database URL
	static final String DB_URL = "jdbc:mysql://www.papademas.net:3307/tickets?autoReconnect=true&useSSL=false";
	// Database credentials
	static final String USER = "fp411", PASS = "411";

	public Connection connect() throws SQLException {

		return DriverManager.getConnection(DB_URL, USER, PASS);

	}

	Statement statement = null;
	// CRUD implementation
			public int insertRecords(String ticketName, String ticketDesc) {
			 int id = 0;
			 try {
				statement = connect().createStatement();
				statement.executeUpdate("Insert into kpate_tickets" + "(ticket_name, ticket_desc) values(" + " '"
				+ ticketName + "','" + ticketDesc + "')", Statement.RETURN_GENERATED_KEYS);

				// retrieve ticket id number newly auto generated upon record insertion
				ResultSet resultSet = null;
				resultSet = statement.getGeneratedKeys();
				if (resultSet.next()) {
					// retrieve first field in table
					id = resultSet.getInt(1);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;

		     }

		     public ResultSet readRecords() {

			ResultSet results = null;
			try {

				Statement statement = connect().createStatement();
				results = statement.executeQuery("SELECT * FROM kpate_tickets");
			    connect().close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			return results;
		     }
		     public void updateRecord(String ColumnName,String value,int tid) {

			try {

				Statement statement = connect().createStatement();
				System.out.println("UPDATE kpate_tickets SET "+ColumnName+" = '"+value +"' WHERE tid = "+tid);
				statement.executeUpdate("UPDATE kpate_tickets SET "+ColumnName+" = '"+value+"' WHERE tid = "+tid);
			    connect().close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		     
		     }
		     public void deleteRecord(int tid) {

					try {

						Statement statement = connect().createStatement();
						System.out.println("DELETE from kpate_tickets WHERE tid = "+tid);
						statement.execute("DELETE from kpate_tickets WHERE tid = "+tid);
					    connect().close();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
			}
	// continue coding for updateRecords implementation 

	     // continue coding for deleteRecords implementation
}
